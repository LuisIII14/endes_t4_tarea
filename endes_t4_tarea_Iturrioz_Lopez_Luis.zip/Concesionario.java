import java.util.ArrayList;
/** 
 * La clase Concesionario representa un concesionario de autom�viles que almacena una lista de autos.
 * @author Luis
 * @version 1.0
 */
public class Concesionario {

/** 
 * La lista de autos en el concesionario
 * Es de tipo lista
 */
    private ArrayList<Auto> autos;

/**
     * Constructor para crear un nuevo objeto Concesionario sin autos inicialmente.
     */
    public Concesionario() {
        autos = new ArrayList<>();
    }

/**
     * Agrega un nuevo auto al concesionario.
     * @param auto El auto a agregar al concesionario.
     */
    public void agregarAuto(Auto auto) {
        autos.add(auto);
    }

/**
     * Obtiene la lista de autos en el concesionario.
     * @return La lista de autos en el concesionario.
     */
    public ArrayList<Auto> listarAutos() {
        return autos;
    }

/**
     * Imprime los autos almacenados en el concesionario.
     */
    public void imprimirAutos(){
        for (Auto auto: autos){
            System.out.println(auto);
        }
    }
}

