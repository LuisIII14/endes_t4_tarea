
import java.util.ArrayList;

/**
 * La clase Auto representa un objeto que contiene informaci�n sobre un autom�vil, incluida su marca y modelo.
 *
 * @author Luis
 * @version 1.0
 */
public class Auto {

    /** 
     * La marca del autom�vil. 
     *Variable tipo String
     */
    private String marca;
    
    /**
     *El modelo del autom�vil. 
     *Variable tipo String
     */
    private String modelo;

    /**
     * Constructor para crear un objeto Auto Lo crea con la marca y modelo
     * especificados.
     * @param marca La marca del autom�vil.
     * @param modelo El modelo del autom�vil.
     */
    public Auto(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }

    /**
     * Obtiene la marca del autom�vil.
     * @return La marca del autom�vil.
     */
    public String getMarca() {
        return marca;
    }

    /**
     * Establece la marca del autom�vil.
     * @param marca La nueva marca del autom�vil.
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * Obtiene el modelo del autom�vil.
     * @return El modelo del autom�vil.
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * Establece el modelo del autom�vil.
     * @param modelo El modelo del autom�vil.
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * Devuelve una representaci�n en forma de cadena de este objeto Auto.
     * @return Una cadena que representa este objeto Auto, incluyendo su marca y
     * modelo.
     */
    @Override
    public String toString() {
        return "Auto [marca=" + marca + ", modelo=" + modelo + "]";
    }
}
