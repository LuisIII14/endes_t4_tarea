/**
 * La clase Main es la clase principal que contiene el m�todo main
 * @author  Luis
 * @version  1.0
 */
public class Main {
    
        
    /**
     * El m�todo main es el metodo principal del programa.
     * Crea instancias de Auto, las agrega al Concesionario y luego imprime la lista de autos.
     * @param args Es para los los par�metros que el reciba por consola
     * @return no devuelve nada pues es de tipo  void
     * /
    
    public static void main(String[] args) {
        Auto auto1 = new Auto("Peugeot", "308");
        Auto auto2 = new Auto("Seat", "Leon");

        Concesionario concesionario1 = new Concesionario();

        concesionario1.agregarAuto(auto1);
        concesionario1.agregarAuto(auto2);

        concesionario1.imprimirAutos();
    }
}
